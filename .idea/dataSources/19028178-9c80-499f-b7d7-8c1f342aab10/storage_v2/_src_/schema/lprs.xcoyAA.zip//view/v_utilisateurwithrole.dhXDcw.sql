create definer = root@localhost view v_utilisateurwithrole as
select `u`.`id_utilisateur`    AS `id_utilisateur`,
       `u`.`nom`               AS `nom`,
       `u`.`prenom`            AS `prenom`,
       `u`.`email`             AS `email`,
       `u`.`mdp`               AS `mdp`,
       `u`.`date_inscription`  AS `date_inscription`,
       `u`.`statut_validation` AS `statut_validation`,
       'alumni'                AS `role`
from (`lprs`.`alumni` `a` join `lprs`.`utilisateur` `u` on ((`u`.`id_utilisateur` = `a`.`ref_utilisateur`)))
union
select `u`.`id_utilisateur`    AS `id_utilisateur`,
       `u`.`nom`               AS `nom`,
       `u`.`prenom`            AS `prenom`,
       `u`.`email`             AS `email`,
       `u`.`mdp`               AS `mdp`,
       `u`.`date_inscription`  AS `date_inscription`,
       `u`.`statut_validation` AS `statut_validation`,
       'etudiant'              AS `role`
from (`lprs`.`etudiant` `e` join `lprs`.`utilisateur` `u` on ((`u`.`id_utilisateur` = `e`.`ref_utilisateur`)))
union
select `u`.`id_utilisateur`    AS `id_utilisateur`,
       `u`.`nom`               AS `nom`,
       `u`.`prenom`            AS `prenom`,
       `u`.`email`             AS `email`,
       `u`.`mdp`               AS `mdp`,
       `u`.`date_inscription`  AS `date_inscription`,
       `u`.`statut_validation` AS `statut_validation`,
       'partenaire'            AS `role`
from (`lprs`.`partenaire` `p` join `lprs`.`utilisateur` `u` on ((`u`.`id_utilisateur` = `p`.`ref_utilisateur`)))
union
select `u`.`id_utilisateur`    AS `id_utilisateur`,
       `u`.`nom`               AS `nom`,
       `u`.`prenom`            AS `prenom`,
       `u`.`email`             AS `email`,
       `u`.`mdp`               AS `mdp`,
       `u`.`date_inscription`  AS `date_inscription`,
       `u`.`statut_validation` AS `statut_validation`,
       'professeur'            AS `role`
from (`lprs`.`professeur` `pr` join `lprs`.`utilisateur` `u` on ((`u`.`id_utilisateur` = `pr`.`ref_utilisateur`)));

